/**
 * This is a comparator class which has one member function -
 * isLessThan. This member function can be used to compare
 * Rectangles by their area.
 * Author: Kerry Gip
 * Version: 08302020
 */
#include "Rectangle.h"
#ifndef HW2_RECTANGLEAREACOMPARATOR_H
#define HW2_RECTANGLEAREACOMPARATOR_H

class RectangleAreaComparator {
public:

    /**
     * This function can be used to compare two Rectangles based
     * on their area. It will return true if area of left
     * Rectangle is less than the area of right Rectangle
     * Changed from rhs to R1/R2 and lhs to L1/L2
     * @param l1 Rectangle object
     * @param rhs Rectangle object
     * @return true if left Rectangle < right Rectangle, otherwise
     * it will return false
     */
    bool isLessThan (const Rectangle & lhs, const Rectangle & rhs) {
        //Write the code needed to compare Rectangle based on their area
        if ((lhs.getWidth()) *(rhs.getLength()) < (lhs.getWidth())*(rhs.getLength()))
            return true;
        else return false;


    }
};




#endif //HW2_RECTANGLEAREACOMPARATOR_H
