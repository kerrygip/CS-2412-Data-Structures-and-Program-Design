/******************************************************************************

README:

Name: Kerry Gip
Assisted files: Dr. Salim Lakhani
Student ID: 830354146
Class: CSCI 2421
HW #2
Due: 8/30/2020
Description of program: Define a Rectangle class that provides getLength and getWidth. 
Using findMAX, wrote a main that creates an array of Rectangle and finds the largest Rectangle 
first on the basis of area and then on the basis of perimeter

Status of Program: Working

Hardware: VS Code version 1.48

How to compile:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          

Source Files: 
    README.cpp
    main.cpp
    Rectangle.cpp
    Rectangle.h
    RectangleAreaComparator.h
    RectanglePerimiterComparator.h


Name: README.cpp
    Has the basic information about how to use the files, the users and what it is supposed to do

Name: main.cpp
    The main function that creates the rectangles

Name: Rectangle.cpp
    Header for rectangle class

Name:Rectangle.h
    Another header for rectangle class

Name:RectangleAreaComparator.h
    Contains isLessThan operator. Compares rectangles by area

Name: RectanglePerimiterComparator.h
    Contains isLessThan function. Compares rectangles by perimeter


*******************************************************************************/